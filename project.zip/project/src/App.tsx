import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import CategoryView from './components/CategoryView';
import ActivityForm from './components/ActivityForm';
import { Activity, ActivityCategory, CarbonData } from './types';
import { generateCarbonData } from './utils/carbonCalculations';
import { createActivity } from './data/activities';

// Sample initial activities
const initialActivities: Activity[] = [
  createActivity('car', 25, '2025-05-01'),
  createActivity('electricity', 120, '2025-05-01'),
  createActivity('beef', 0.5, '2025-05-01'),
  createActivity('car', 15, '2025-05-02'),
  createActivity('vegetables', 2, '2025-05-02'),
  createActivity('electricity', 100, '2025-05-03'),
  createActivity('train', 50, '2025-05-03'),
  createActivity('chicken', 0.8, '2025-05-04'),
  createActivity('car', 30, '2025-05-04'),
  createActivity('natural_gas', 80, '2025-05-05'),
  createActivity('recycling', 3, '2025-05-05'),
  createActivity('bus', 20, '2025-05-06'),
  createActivity('clothing', 2, '2025-05-06'),
  createActivity('electricity', 110, '2025-05-07'),
  createActivity('vegetables', 1.5, '2025-05-07'),
];

function App() {
  const [activities, setActivities] = useState<Activity[]>(initialActivities);
  const [carbonData, setCarbonData] = useState<CarbonData>({
    totalFootprint: 0,
    categoryBreakdown: {
      [ActivityCategory.Transportation]: 0,
      [ActivityCategory.Energy]: 0,
      [ActivityCategory.Food]: 0,
      [ActivityCategory.Shopping]: 0,
      [ActivityCategory.Waste]: 0,
    },
    dailyData: [],
    monthlyAverage: 0,
    previousMonthComparison: 0,
  });
  
  const [selectedCategory, setSelectedCategory] = useState<ActivityCategory | null>(null);
  const [showActivityForm, setShowActivityForm] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // Calculate carbon data whenever activities change
  useEffect(() => {
    const newCarbonData = generateCarbonData(activities);
    setCarbonData(newCarbonData);
  }, [activities]);
  
  const handleAddActivity = (activity: Activity) => {
    setActivities(prev => [...prev, activity]);
  };
  
  const handleCategorySelect = (category: ActivityCategory | null) => {
    setSelectedCategory(category);
    setSidebarOpen(false);
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header toggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar 
          isOpen={sidebarOpen} 
          onClose={() => setSidebarOpen(false)} 
          onCategorySelect={handleCategorySelect}
          selectedCategory={selectedCategory}
        />
        
        <main className="flex-1 overflow-y-auto md:ml-64">
          {selectedCategory ? (
            <CategoryView 
              category={selectedCategory} 
              activities={activities}
              carbonData={carbonData}
              onAddActivity={() => setShowActivityForm(true)}
            />
          ) : (
            <Dashboard 
              activities={activities} 
              carbonData={carbonData}
              onAddActivity={() => setShowActivityForm(true)}
            />
          )}
        </main>
      </div>
      
      {showActivityForm && (
        <ActivityForm 
          onAddActivity={handleAddActivity} 
          onClose={() => setShowActivityForm(false)}
          selectedCategory={selectedCategory}
        />
      )}
    </div>
  );
}

export default App;