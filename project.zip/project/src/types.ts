export interface Activity {
  id: string;
  name: string;
  category: ActivityCategory;
  icon: string;
  carbonPerUnit: number;
  unit: string;
  value: number;
  date: string;
}

export enum ActivityCategory {
  Transportation = "Transportation",
  Energy = "Energy",
  Food = "Food",
  Shopping = "Shopping",
  Waste = "Waste"
}

export interface Suggestion {
  id: string;
  title: string;
  description: string;
  category: ActivityCategory;
  savingPotential: number;
  difficulty: "Easy" | "Medium" | "Hard";
}

export interface CarbonData {
  totalFootprint: number;
  categoryBreakdown: Record<ActivityCategory, number>;
  dailyData: {
    date: string;
    value: number;
  }[];
  monthlyAverage: number;
  previousMonthComparison: number;
}