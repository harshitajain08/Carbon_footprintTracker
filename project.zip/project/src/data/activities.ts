import { Activity, ActivityCategory } from '../types';
import { v4 as uuidv4 } from 'uuid';

export const activityOptions = [
  // Transportation
  {
    id: "car",
    name: "Car Travel",
    category: ActivityCategory.Transportation,
    icon: "car",
    carbonPerUnit: 0.192, // kg CO2 per km
    unit: "kilometers"
  },
  {
    id: "bus",
    name: "Bus Travel",
    category: ActivityCategory.Transportation,
    icon: "bus",
    carbonPerUnit: 0.105, // kg CO2 per km
    unit: "kilometers"
  },
  {
    id: "train",
    name: "Train Travel",
    category: ActivityCategory.Transportation,
    icon: "train",
    carbonPerUnit: 0.041, // kg CO2 per km
    unit: "kilometers"
  },
  {
    id: "flight",
    name: "Flight",
    category: ActivityCategory.Transportation,
    icon: "plane",
    carbonPerUnit: 0.255, // kg CO2 per km
    unit: "kilometers"
  },
  {
    id: "motorcycle",
    name: "Motorcycle",
    category: ActivityCategory.Transportation,
    icon: "bike",
    carbonPerUnit: 0.103, // kg CO2 per km
    unit: "kilometers"
  },
  
  // Energy
  {
    id: "electricity",
    name: "Electricity Usage",
    category: ActivityCategory.Energy,
    icon: "zap",
    carbonPerUnit: 0.233, // kg CO2 per kWh (varies by country)
    unit: "kWh"
  },
  {
    id: "natural_gas",
    name: "Natural Gas",
    category: ActivityCategory.Energy,
    icon: "flame",
    carbonPerUnit: 0.184, // kg CO2 per kWh
    unit: "kWh"
  },
  {
    id: "heating_oil",
    name: "Heating Oil",
    category: ActivityCategory.Energy,
    icon: "droplets",
    carbonPerUnit: 2.54, // kg CO2 per liter
    unit: "liters"
  },
  
  // Food
  {
    id: "beef",
    name: "Beef Consumption",
    category: ActivityCategory.Food,
    icon: "beef",
    carbonPerUnit: 27, // kg CO2 per kg
    unit: "kg"
  },
  {
    id: "chicken",
    name: "Chicken Consumption",
    category: ActivityCategory.Food,
    icon: "drumstick",
    carbonPerUnit: 6.9, // kg CO2 per kg
    unit: "kg"
  },
  {
    id: "pork",
    name: "Pork Consumption",
    category: ActivityCategory.Food,
    icon: "bacon",
    carbonPerUnit: 12.1, // kg CO2 per kg
    unit: "kg"
  },
  {
    id: "fish",
    name: "Fish Consumption",
    category: ActivityCategory.Food,
    icon: "fish",
    carbonPerUnit: 6.1, // kg CO2 per kg
    unit: "kg"
  },
  {
    id: "dairy",
    name: "Dairy Products",
    category: ActivityCategory.Food,
    icon: "milk",
    carbonPerUnit: 1.9, // kg CO2 per kg
    unit: "kg"
  },
  {
    id: "vegetables",
    name: "Vegetables",
    category: ActivityCategory.Food,
    icon: "salad",
    carbonPerUnit: 0.37, // kg CO2 per kg
    unit: "kg"
  },
  
  // Shopping
  {
    id: "clothing",
    name: "Clothing Purchase",
    category: ActivityCategory.Shopping,
    icon: "shirt",
    carbonPerUnit: 15, // kg CO2 per item (average)
    unit: "items"
  },
  {
    id: "electronics",
    name: "Electronics",
    category: ActivityCategory.Shopping,
    icon: "smartphone",
    carbonPerUnit: 45, // kg CO2 per item (average)
    unit: "items"
  },
  
  // Waste
  {
    id: "landfill_waste",
    name: "Landfill Waste",
    category: ActivityCategory.Waste,
    icon: "trash",
    carbonPerUnit: 0.58, // kg CO2 per kg
    unit: "kg"
  },
  {
    id: "recycling",
    name: "Recycling",
    category: ActivityCategory.Waste,
    icon: "recycle",
    carbonPerUnit: 0.21, // kg CO2 per kg
    unit: "kg"
  }
];

export const createActivity = (
  activityId: string,
  value: number,
  date: string = new Date().toISOString().split('T')[0]
): Activity => {
  const activityTemplate = activityOptions.find(a => a.id === activityId);
  
  if (!activityTemplate) {
    throw new Error(`Activity with ID ${activityId} not found`);
  }
  
  return {
    id: uuidv4(),
    name: activityTemplate.name,
    category: activityTemplate.category,
    icon: activityTemplate.icon,
    carbonPerUnit: activityTemplate.carbonPerUnit,
    unit: activityTemplate.unit,
    value,
    date
  };
};