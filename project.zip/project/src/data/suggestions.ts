import { Suggestion, ActivityCategory } from '../types';

export const suggestions: Suggestion[] = [
  // Transportation suggestions
  {
    id: "t1",
    title: "Use public transportation",
    description: "Taking the bus or train instead of driving can reduce your carbon emissions by up to 70%.",
    category: ActivityCategory.Transportation,
    savingPotential: 0.15,
    difficulty: "Medium"
  },
  {
    id: "t2",
    title: "Carpool to work",
    description: "Sharing rides with colleagues can cut your commuting emissions in half.",
    category: ActivityCategory.Transportation,
    savingPotential: 0.10,
    difficulty: "Easy"
  },
  {
    id: "t3",
    title: "Switch to cycling for short trips",
    description: "For distances under 5km, cycling produces zero emissions and improves your health.",
    category: ActivityCategory.Transportation,
    savingPotential: 0.05,
    difficulty: "Medium"
  },
  {
    id: "t4",
    title: "Consider an electric vehicle",
    description: "Electric vehicles produce significantly fewer emissions over their lifetime compared to gas vehicles.",
    category: ActivityCategory.Transportation,
    savingPotential: 0.30,
    difficulty: "Hard"
  },
  
  // Energy suggestions
  {
    id: "e1",
    title: "Switch to LED light bulbs",
    description: "LED bulbs use up to 80% less energy than traditional incandescent bulbs.",
    category: ActivityCategory.Energy,
    savingPotential: 0.03,
    difficulty: "Easy"
  },
  {
    id: "e2",
    title: "Install a programmable thermostat",
    description: "Automatically adjusting your home temperature can save up to 10% on heating and cooling costs.",
    category: ActivityCategory.Energy,
    savingPotential: 0.08,
    difficulty: "Medium"
  },
  {
    id: "e3",
    title: "Unplug electronics when not in use",
    description: "Phantom power can account for up to 10% of your home's energy use.",
    category: ActivityCategory.Energy,
    savingPotential: 0.05,
    difficulty: "Easy"
  },
  {
    id: "e4",
    title: "Switch to renewable energy",
    description: "Many utility companies offer green energy options that significantly reduce your carbon footprint.",
    category: ActivityCategory.Energy,
    savingPotential: 0.40,
    difficulty: "Medium"
  },
  
  // Food suggestions
  {
    id: "f1",
    title: "Reduce meat consumption",
    description: "Having one meatless day per week can reduce your food carbon footprint by about 15%.",
    category: ActivityCategory.Food,
    savingPotential: 0.15,
    difficulty: "Medium"
  },
  {
    id: "f2",
    title: "Buy local and seasonal produce",
    description: "Local food travels shorter distances and seasonal produce requires less energy to grow.",
    category: ActivityCategory.Food,
    savingPotential: 0.05,
    difficulty: "Easy"
  },
  {
    id: "f3",
    title: "Reduce food waste",
    description: "Plan meals, store food properly, and use leftovers to reduce the 30% of food that typically goes to waste.",
    category: ActivityCategory.Food,
    savingPotential: 0.10,
    difficulty: "Easy"
  },
  {
    id: "f4",
    title: "Try plant-based alternatives",
    description: "Plant-based proteins like beans and lentils have a much lower carbon footprint than animal proteins.",
    category: ActivityCategory.Food,
    savingPotential: 0.20,
    difficulty: "Medium"
  },
  
  // Shopping suggestions
  {
    id: "s1",
    title: "Buy second-hand items",
    description: "Second-hand clothing and electronics extend product lifecycles and prevent manufacturing emissions.",
    category: ActivityCategory.Shopping,
    savingPotential: 0.15,
    difficulty: "Easy"
  },
  {
    id: "s2",
    title: "Choose durable, high-quality products",
    description: "Products that last longer reduce the need for replacements and associated manufacturing emissions.",
    category: ActivityCategory.Shopping,
    savingPotential: 0.10,
    difficulty: "Medium"
  },
  {
    id: "s3",
    title: "Repair instead of replace",
    description: "Fixing broken items instead of buying new ones saves resources and reduces waste.",
    category: ActivityCategory.Shopping,
    savingPotential: 0.08,
    difficulty: "Medium"
  },
  
  // Waste suggestions
  {
    id: "w1",
    title: "Start composting",
    description: "Composting food scraps reduces methane emissions from landfills and creates nutrient-rich soil.",
    category: ActivityCategory.Waste,
    savingPotential: 0.05,
    difficulty: "Medium"
  },
  {
    id: "w2",
    title: "Improve recycling habits",
    description: "Learn your local recycling rules and properly sort materials to maximize recycling efficiency.",
    category: ActivityCategory.Waste,
    savingPotential: 0.07,
    difficulty: "Easy"
  },
  {
    id: "w3",
    title: "Use reusable alternatives",
    description: "Replace single-use items like water bottles, coffee cups, and shopping bags with reusable versions.",
    category: ActivityCategory.Waste,
    savingPotential: 0.03,
    difficulty: "Easy"
  }
];

export const getSuggestionsByCategory = (category: ActivityCategory): Suggestion[] => {
  return suggestions.filter(suggestion => suggestion.category === category);
};

export const getTopSuggestions = (count: number = 3): Suggestion[] => {
  return [...suggestions].sort((a, b) => b.savingPotential - a.savingPotential).slice(0, count);
};