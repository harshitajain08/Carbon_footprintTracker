import { Activity, ActivityCategory, CarbonData } from '../types';

export const calculateTotalFootprint = (activities: Activity[]): number => {
  return activities.reduce((total, activity) => {
    return total + (activity.value * activity.carbonPerUnit);
  }, 0);
};

export const calculateCategoryBreakdown = (activities: Activity[]): Record<ActivityCategory, number> => {
  const initialBreakdown = Object.values(ActivityCategory).reduce((acc, category) => {
    acc[category] = 0;
    return acc;
  }, {} as Record<ActivityCategory, number>);

  return activities.reduce((breakdown, activity) => {
    breakdown[activity.category] += activity.value * activity.carbonPerUnit;
    return breakdown;
  }, initialBreakdown);
};

export const calculateDailyData = (activities: Activity[]): { date: string; value: number }[] => {
  const dailyMap = new Map<string, number>();
  
  activities.forEach(activity => {
    const date = activity.date;
    const carbonValue = activity.value * activity.carbonPerUnit;
    
    if (dailyMap.has(date)) {
      dailyMap.set(date, dailyMap.get(date)! + carbonValue);
    } else {
      dailyMap.set(date, carbonValue);
    }
  });
  
  // Convert to array and sort by date
  return Array.from(dailyMap.entries())
    .map(([date, value]) => ({ date, value }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};

export const calculateMonthlyAverage = (activities: Activity[]): number => {
  if (activities.length === 0) return 0;
  
  const now = new Date();
  const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  
  const thisMonthActivities = activities.filter(activity => 
    new Date(activity.date) >= firstDayOfMonth
  );
  
  if (thisMonthActivities.length === 0) return 0;
  
  const totalCarbon = calculateTotalFootprint(thisMonthActivities);
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysPassed = Math.min(now.getDate(), daysInMonth);
  
  return totalCarbon / daysPassed;
};

export const calculatePreviousMonthComparison = (activities: Activity[]): number => {
  if (activities.length === 0) return 0;
  
  const now = new Date();
  const firstDayOfCurrentMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const firstDayOfPreviousMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const lastDayOfPreviousMonth = new Date(now.getFullYear(), now.getMonth(), 0);
  
  const currentMonthActivities = activities.filter(activity => 
    new Date(activity.date) >= firstDayOfCurrentMonth
  );
  
  const previousMonthActivities = activities.filter(activity => {
    const activityDate = new Date(activity.date);
    return activityDate >= firstDayOfPreviousMonth && activityDate <= lastDayOfPreviousMonth;
  });
  
  const currentMonthTotal = calculateTotalFootprint(currentMonthActivities);
  const previousMonthTotal = calculateTotalFootprint(previousMonthActivities);
  
  if (previousMonthTotal === 0) return 0;
  
  // Calculate the percentage change
  return ((currentMonthTotal - previousMonthTotal) / previousMonthTotal) * 100;
};

export const getFootprintRating = (totalFootprint: number): {
  rating: 'Excellent' | 'Good' | 'Average' | 'Poor' | 'Very Poor',
  color: string
} => {
  // These thresholds are examples and should be adjusted based on actual data
  if (totalFootprint < 50) {
    return { rating: 'Excellent', color: 'text-primary-600' };
  } else if (totalFootprint < 100) {
    return { rating: 'Good', color: 'text-primary-500' };
  } else if (totalFootprint < 200) {
    return { rating: 'Average', color: 'text-warning-500' };
  } else if (totalFootprint < 300) {
    return { rating: 'Poor', color: 'text-warning-600' };
  } else {
    return { rating: 'Very Poor', color: 'text-danger-600' };
  }
};

export const generateCarbonData = (activities: Activity[]): CarbonData => {
  return {
    totalFootprint: calculateTotalFootprint(activities),
    categoryBreakdown: calculateCategoryBreakdown(activities),
    dailyData: calculateDailyData(activities),
    monthlyAverage: calculateMonthlyAverage(activities),
    previousMonthComparison: calculatePreviousMonthComparison(activities)
  };
};