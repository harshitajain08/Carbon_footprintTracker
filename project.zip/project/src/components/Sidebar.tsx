import React from 'react';
import { 
  Home, 
  BarChart2, 
  PlusCircle, 
  Settings, 
  HelpCircle, 
  X,
  Car,
  Zap,
  Utensils,
  ShoppingBag,
  Trash2
} from 'lucide-react';
import { ActivityCategory } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onCategorySelect: (category: ActivityCategory | null) => void;
  selectedCategory: ActivityCategory | null;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  isOpen, 
  onClose, 
  onCategorySelect,
  selectedCategory
}) => {
  const categoryIcons = {
    [ActivityCategory.Transportation]: <Car className="w-5 h-5" />,
    [ActivityCategory.Energy]: <Zap className="w-5 h-5" />,
    [ActivityCategory.Food]: <Utensils className="w-5 h-5" />,
    [ActivityCategory.Shopping]: <ShoppingBag className="w-5 h-5" />,
    [ActivityCategory.Waste]: <Trash2 className="w-5 h-5" />
  };

  return (
    <div className={`fixed inset-y-0 left-0 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 z-30 transition duration-300 ease-in-out`}>
      <div className="h-full w-64 bg-white shadow-lg flex flex-col">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Menu</h2>
          <button onClick={onClose} className="md:hidden p-1 rounded-full hover:bg-gray-100">
            <X className="h-5 w-5 text-gray-600" />
          </button>
        </div>
        
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-2 px-4">
            <li>
              <button 
                onClick={() => onCategorySelect(null)}
                className={`flex items-center space-x-3 w-full p-3 rounded-lg ${!selectedCategory ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <Home className="h-5 w-5" />
                <span>Dashboard</span>
              </button>
            </li>
            
            <li className="pt-4">
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-3">
                Activity Categories
              </div>
              
              {Object.values(ActivityCategory).map((category) => (
                <button 
                  key={category}
                  onClick={() => onCategorySelect(category)}
                  className={`flex items-center space-x-3 w-full p-3 rounded-lg ${selectedCategory === category ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}
                >
                  {categoryIcons[category]}
                  <span>{category}</span>
                </button>
              ))}
            </li>
            
            <li className="pt-4">
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-3">
                Analysis
              </div>
              
              <button className="flex items-center space-x-3 w-full p-3 rounded-lg text-gray-700 hover:bg-gray-100">
                <BarChart2 className="h-5 w-5" />
                <span>Reports</span>
              </button>
            </li>
          </ul>
        </nav>
        
        <div className="p-4 border-t">
          <button className="flex items-center justify-center space-x-2 w-full p-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
            <PlusCircle className="h-5 w-5" />
            <span>Add Activity</span>
          </button>
          
          <div className="flex justify-between mt-4">
            <button className="p-2 text-gray-600 hover:text-gray-900">
              <Settings className="h-5 w-5" />
            </button>
            <button className="p-2 text-gray-600 hover:text-gray-900">
              <HelpCircle className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={onClose}
        />
      )}
    </div>
  );
};

export default Sidebar;