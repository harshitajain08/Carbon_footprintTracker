import React from 'react';
import { Activity, CarbonData } from '../types';
import { ArrowUpRight, ArrowDownRight, TrendingUp } from 'lucide-react';
import { getFootprintRating } from '../utils/carbonCalculations';
import CarbonChart from './charts/CarbonChart';
import CategoryBreakdownChart from './charts/CategoryBreakdownChart';
import DailyTrendsChart from './charts/DailyTrendsChart';
import SuggestionsList from './SuggestionsList';
import RecentActivities from './RecentActivities';

interface DashboardProps {
  activities: Activity[];
  carbonData: CarbonData;
  onAddActivity: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ activities, carbonData, onAddActivity }) => {
  const { rating, color } = getFootprintRating(carbonData.totalFootprint);
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-gray-800">Carbon Footprint Dashboard</h1>
          <p className="text-gray-600 mt-1">Track, analyze, and reduce your environmental impact</p>
        </div>
        
        <button 
          onClick={onAddActivity}
          className="mt-4 md:mt-0 bg-primary-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-primary-700 transition-colors flex items-center space-x-2"
        >
          <span>Add New Activity</span>
          <TrendingUp className="h-5 w-5" />
        </button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500 text-sm">Total Carbon Footprint</p>
              <h3 className="text-2xl font-bold mt-1">{carbonData.totalFootprint.toFixed(2)} kg CO₂</h3>
            </div>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${color} bg-opacity-10`}>
              {rating}
            </span>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <p className="text-gray-500 text-sm">Daily Average</p>
          <h3 className="text-2xl font-bold mt-1">{(carbonData.totalFootprint / Math.max(1, activities.length)).toFixed(2)} kg CO₂</h3>
          <div className="flex items-center mt-2 text-sm">
            <span className={carbonData.previousMonthComparison >= 0 ? "text-danger-500" : "text-primary-500"}>
              {carbonData.previousMonthComparison >= 0 ? (
                <ArrowUpRight className="h-4 w-4 inline" />
              ) : (
                <ArrowDownRight className="h-4 w-4 inline" />
              )}
              {Math.abs(carbonData.previousMonthComparison).toFixed(1)}% from last month
            </span>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <p className="text-gray-500 text-sm">Activities Tracked</p>
          <h3 className="text-2xl font-bold mt-1">{activities.length}</h3>
          <p className="text-sm text-gray-500 mt-2">Across {Object.keys(carbonData.categoryBreakdown).length} categories</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <p className="text-gray-500 text-sm">Monthly Projection</p>
          <h3 className="text-2xl font-bold mt-1">{(carbonData.monthlyAverage * 30).toFixed(2)} kg CO₂</h3>
          <p className="text-sm text-gray-500 mt-2">Based on current activity</p>
        </div>
      </div>
      
      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Carbon Footprint by Category</h3>
          <div className="h-80">
            <CategoryBreakdownChart categoryBreakdown={carbonData.categoryBreakdown} />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Daily Carbon Trends</h3>
          <div className="h-80">
            <DailyTrendsChart dailyData={carbonData.dailyData} />
          </div>
        </div>
      </div>
      
      {/* Recent Activities and Suggestions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Activities</h3>
          <RecentActivities activities={activities.slice(0, 5)} />
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Eco-Friendly Suggestions</h3>
          <SuggestionsList totalFootprint={carbonData.totalFootprint} categoryBreakdown={carbonData.categoryBreakdown} />
        </div>
      </div>
      
      {/* Overall Trend */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Carbon Footprint Over Time</h3>
        <div className="h-80">
          <CarbonChart dailyData={carbonData.dailyData} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;