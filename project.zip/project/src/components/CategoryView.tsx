import React from 'react';
import { Activity, ActivityCategory, CarbonData } from '../types';
import { getFootprintRating } from '../utils/carbonCalculations';
import { TrendingUp, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import CategoryBreakdownChart from './charts/CategoryBreakdownChart';
import DailyTrendsChart from './charts/DailyTrendsChart';
import RecentActivities from './RecentActivities';
import SuggestionsList from './SuggestionsList';

interface CategoryViewProps {
  category: ActivityCategory;
  activities: Activity[];
  carbonData: CarbonData;
  onAddActivity: () => void;
}

const CategoryView: React.FC<CategoryViewProps> = ({ 
  category, 
  activities, 
  carbonData,
  onAddActivity
}) => {
  // Filter activities by the selected category
  const categoryActivities = activities.filter(activity => activity.category === category);
  
  // Calculate category total
  const categoryTotal = carbonData.categoryBreakdown[category];
  
  // Get rating for this category
  const { rating, color } = getFootprintRating(categoryTotal);
  
  // Calculate percentage of total
  const percentageOfTotal = carbonData.totalFootprint > 0 
    ? (categoryTotal / carbonData.totalFootprint) * 100 
    : 0;
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-gray-800">{category}</h1>
          <p className="text-gray-600 mt-1">Detailed analysis of your {category.toLowerCase()} carbon footprint</p>
        </div>
        
        <button 
          onClick={onAddActivity}
          className="mt-4 md:mt-0 bg-primary-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-primary-700 transition-colors flex items-center space-x-2"
        >
          <span>Add {category} Activity</span>
          <TrendingUp className="h-5 w-5" />
        </button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500 text-sm">{category} Carbon Footprint</p>
              <h3 className="text-2xl font-bold mt-1">{categoryTotal.toFixed(2)} kg CO₂</h3>
            </div>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${color} bg-opacity-10`}>
              {rating}
            </span>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <p className="text-gray-500 text-sm">Percentage of Total</p>
          <h3 className="text-2xl font-bold mt-1">{percentageOfTotal.toFixed(1)}%</h3>
          <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
            <div 
              className="bg-primary-600 h-2.5 rounded-full" 
              style={{ width: `${percentageOfTotal}%` }}
            ></div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <p className="text-gray-500 text-sm">Activities Tracked</p>
          <h3 className="text-2xl font-bold mt-1">{categoryActivities.length}</h3>
          <p className="text-sm text-gray-500 mt-2">In this category</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <p className="text-gray-500 text-sm">Average per Activity</p>
          <h3 className="text-2xl font-bold mt-1">
            {categoryActivities.length > 0 
              ? (categoryTotal / categoryActivities.length).toFixed(2) 
              : '0.00'} kg CO₂
          </h3>
        </div>
      </div>
      
      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">{category} vs Other Categories</h3>
          <div className="h-80">
            <CategoryBreakdownChart categoryBreakdown={carbonData.categoryBreakdown} highlightCategory={category} />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">{category} Activities Over Time</h3>
          <div className="h-80">
            <DailyTrendsChart 
              dailyData={carbonData.dailyData} 
              categoryFilter={category}
              activities={activities}
            />
          </div>
        </div>
      </div>
      
      {/* Recent Activities and Suggestions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent {category} Activities</h3>
          {categoryActivities.length > 0 ? (
            <RecentActivities activities={categoryActivities.slice(0, 5)} />
          ) : (
            <p className="text-gray-500 py-4">No activities recorded for this category yet.</p>
          )}
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Eco-Friendly Suggestions</h3>
          <SuggestionsList 
            totalFootprint={carbonData.totalFootprint} 
            categoryBreakdown={carbonData.categoryBreakdown}
            specificCategory={category}
          />
        </div>
      </div>
    </div>
  );
};

export default CategoryView;