import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';
import { ActivityCategory } from '../../types';

ChartJS.register(ArcElement, Tooltip, Legend);

interface CategoryBreakdownChartProps {
  categoryBreakdown: Record<ActivityCategory, number>;
  highlightCategory?: ActivityCategory;
}

const CategoryBreakdownChart: React.FC<CategoryBreakdownChartProps> = ({ 
  categoryBreakdown,
  highlightCategory
}) => {
  const categories = Object.keys(categoryBreakdown) as ActivityCategory[];
  const values = categories.map(cat => categoryBreakdown[cat]);
  
  const categoryColors = {
    [ActivityCategory.Transportation]: '#0284c7', // secondary-600
    [ActivityCategory.Energy]: '#f59e0b', // warning-500
    [ActivityCategory.Food]: '#16a34a', // primary-600
    [ActivityCategory.Shopping]: '#38bdf8', // secondary-400
    [ActivityCategory.Waste]: '#ef4444', // danger-500
  };
  
  const backgroundColors = categories.map(category => {
    if (highlightCategory && category !== highlightCategory) {
      // Make non-highlighted categories more transparent
      return `${categoryColors[category]}80`;
    }
    return categoryColors[category];
  });
  
  const data = {
    labels: categories,
    datasets: [
      {
        data: values,
        backgroundColor: backgroundColors,
        borderColor: categories.map(category => categoryColors[category]),
        borderWidth: 1,
      },
    ],
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          pointStyle: 'circle',
        },
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const value = context.raw;
            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
            const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0';
            return `${context.label}: ${value.toFixed(2)} kg CO₂ (${percentage}%)`;
          }
        }
      }
    },
  };
  
  return <Pie data={data} options={options} />;
};

export default CategoryBreakdownChart;