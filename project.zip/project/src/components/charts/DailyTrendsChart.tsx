import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { Activity, ActivityCategory } from '../../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface DailyTrendsChartProps {
  dailyData: { date: string; value: number }[];
  categoryFilter?: ActivityCategory;
  activities?: Activity[];
}

const DailyTrendsChart: React.FC<DailyTrendsChartProps> = ({ 
  dailyData,
  categoryFilter,
  activities = []
}) => {
  // If we have a category filter and activities, we need to filter the data
  let filteredData = dailyData;
  
  if (categoryFilter && activities.length > 0) {
    // Create a map of dates to values for the filtered category
    const categoryDailyMap = new Map<string, number>();
    
    activities
      .filter(activity => activity.category === categoryFilter)
      .forEach(activity => {
        const date = activity.date;
        const carbonValue = activity.value * activity.carbonPerUnit;
        
        if (categoryDailyMap.has(date)) {
          categoryDailyMap.set(date, categoryDailyMap.get(date)! + carbonValue);
        } else {
          categoryDailyMap.set(date, carbonValue);
        }
      });
    
    // Convert to array and sort by date
    filteredData = Array.from(categoryDailyMap.entries())
      .map(([date, value]) => ({ date, value }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };
  
  const data = {
    labels: filteredData.map(item => formatDate(item.date)),
    datasets: [
      {
        label: categoryFilter ? `${categoryFilter} Carbon Footprint` : 'Carbon Footprint',
        data: filteredData.map(item => item.value),
        borderColor: categoryFilter ? getCategoryColor(categoryFilter) : '#16a34a',
        backgroundColor: categoryFilter ? `${getCategoryColor(categoryFilter)}20` : 'rgba(22, 163, 74, 0.2)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
      },
    ],
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'kg CO₂',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Date',
        },
      },
    },
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: ${context.raw.toFixed(2)} kg CO₂`;
          }
        }
      }
    },
  };
  
  return <Line data={data} options={options} />;
};

const getCategoryColor = (category: ActivityCategory): string => {
  switch (category) {
    case ActivityCategory.Transportation:
      return '#0284c7'; // secondary-600
    case ActivityCategory.Energy:
      return '#f59e0b'; // warning-500
    case ActivityCategory.Food:
      return '#16a34a'; // primary-600
    case ActivityCategory.Shopping:
      return '#38bdf8'; // secondary-400
    case ActivityCategory.Waste:
      return '#ef4444'; // danger-500
    default:
      return '#16a34a'; // primary-600
  }
};

export default DailyTrendsChart;