import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface CarbonChartProps {
  dailyData: { date: string; value: number }[];
}

const CarbonChart: React.FC<CarbonChartProps> = ({ dailyData }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };
  
  // Calculate 7-day moving average
  const movingAverage = dailyData.map((item, index, array) => {
    if (index < 6) return null; // Not enough data for 7-day average
    
    const sum = array
      .slice(index - 6, index + 1)
      .reduce((acc, curr) => acc + curr.value, 0);
    
    return sum / 7;
  });
  
  const data = {
    labels: dailyData.map(item => formatDate(item.date)),
    datasets: [
      {
        type: 'bar' as const,
        label: 'Daily Carbon Footprint',
        data: dailyData.map(item => item.value),
        backgroundColor: 'rgba(22, 163, 74, 0.6)',
        borderColor: 'rgba(22, 163, 74, 1)',
        borderWidth: 1,
        borderRadius: 4,
      },
      {
        type: 'line' as const,
        label: '7-Day Average',
        data: movingAverage,
        borderColor: 'rgba(14, 165, 233, 1)',
        backgroundColor: 'rgba(14, 165, 233, 0.2)',
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.4,
      },
    ],
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'kg CO₂',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Date',
        },
      },
    },
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            if (context.dataset.label === '7-Day Average' && context.raw === null) {
              return '';
            }
            return `${context.dataset.label}: ${context.raw ? context.raw.toFixed(2) : 0} kg CO₂`;
          }
        }
      }
    },
  };
  
  return <Bar data={data} options={options} />;
};

export default CarbonChart;