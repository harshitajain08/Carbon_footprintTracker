import React, { useState } from 'react';
import { activityOptions, createActivity } from '../data/activities';
import { Activity, ActivityCategory } from '../types';
import { X } from 'lucide-react';

interface ActivityFormProps {
  onAddActivity: (activity: Activity) => void;
  onClose: () => void;
  selectedCategory?: ActivityCategory | null;
}

const ActivityForm: React.FC<ActivityFormProps> = ({ 
  onAddActivity, 
  onClose,
  selectedCategory 
}) => {
  const [selectedActivityId, setSelectedActivityId] = useState<string>('');
  const [value, setValue] = useState<number>(0);
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  
  const filteredOptions = selectedCategory 
    ? activityOptions.filter(option => option.category === selectedCategory)
    : activityOptions;
  
  const selectedActivityOption = activityOptions.find(option => option.id === selectedActivityId);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedActivityId || value <= 0) return;
    
    const newActivity = createActivity(selectedActivityId, value, date);
    onAddActivity(newActivity);
    onClose();
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-gray-800">Add New Activity</h2>
            <button 
              onClick={onClose}
              className="p-1 rounded-full hover:bg-gray-100"
            >
              <X className="h-6 w-6 text-gray-500" />
            </button>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="activity" className="block text-sm font-medium text-gray-700 mb-1">
                Activity Type
              </label>
              <select
                id="activity"
                value={selectedActivityId}
                onChange={(e) => setSelectedActivityId(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
              >
                <option value="">Select an activity</option>
                {filteredOptions.map((option) => (
                  <option key={option.id} value={option.id}>
                    {option.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="value" className="block text-sm font-medium text-gray-700 mb-1">
                {selectedActivityOption ? `Amount (${selectedActivityOption.unit})` : 'Amount'}
              </label>
              <input
                type="number"
                id="value"
                value={value}
                onChange={(e) => setValue(Number(e.target.value))}
                min="0"
                step="0.01"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
              />
            </div>
            
            <div>
              <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">
                Date
              </label>
              <input
                type="date"
                id="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
              />
            </div>
            
            {selectedActivityOption && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">
                  Carbon impact: <span className="font-semibold">{(selectedActivityOption.carbonPerUnit * value).toFixed(2)} kg CO₂</span>
                </p>
                <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${getImpactColor(selectedActivityOption.carbonPerUnit * value)}`}
                    style={{ width: `${Math.min(100, (selectedActivityOption.carbonPerUnit * value) / 3)}%` }}
                  />
                </div>
              </div>
            )}
            
            <div className="flex space-x-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors"
                disabled={!selectedActivityId || value <= 0}
              >
                Add Activity
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

const getImpactColor = (impact: number): string => {
  if (impact < 1) return 'bg-primary-500';
  if (impact < 5) return 'bg-primary-600';
  if (impact < 10) return 'bg-warning-500';
  if (impact < 20) return 'bg-warning-600';
  return 'bg-danger-600';
};

export default ActivityForm;