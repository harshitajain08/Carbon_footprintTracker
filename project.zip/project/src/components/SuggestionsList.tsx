import React from 'react';
import { ActivityCategory } from '../types';
import { getTopSuggestions, getSuggestionsByCategory } from '../data/suggestions';
import { ArrowRight, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

interface SuggestionsListProps {
  totalFootprint: number;
  categoryBreakdown: Record<ActivityCategory, number>;
  specificCategory?: ActivityCategory;
}

const SuggestionsList: React.FC<SuggestionsListProps> = ({ 
  totalFootprint, 
  categoryBreakdown,
  specificCategory
}) => {
  // Get suggestions based on whether we're viewing a specific category
  const suggestions = specificCategory 
    ? getSuggestionsByCategory(specificCategory).slice(0, 3)
    : getTopSuggestions(3);
  
  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy':
        return <CheckCircle className="h-4 w-4 text-primary-500" />;
      case 'Medium':
        return <AlertTriangle className="h-4 w-4 text-warning-500" />;
      case 'Hard':
        return <XCircle className="h-4 w-4 text-danger-500" />;
      default:
        return null;
    }
  };
  
  const getImpactText = (savingPotential: number) => {
    const potentialSaving = totalFootprint * savingPotential;
    return `Save up to ${potentialSaving.toFixed(1)} kg CO₂`;
  };
  
  if (suggestions.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No suggestions available.</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {suggestions.map((suggestion) => (
        <div key={suggestion.id} className="border border-gray-100 rounded-lg p-4 hover:bg-gray-50 transition-colors">
          <div className="flex justify-between">
            <h4 className="font-medium text-gray-900">{suggestion.title}</h4>
            <div className="flex items-center space-x-1 text-sm">
              {getDifficultyIcon(suggestion.difficulty)}
              <span className="text-gray-500">{suggestion.difficulty}</span>
            </div>
          </div>
          
          <p className="text-gray-600 text-sm mt-2">{suggestion.description}</p>
          
          <div className="flex justify-between items-center mt-4">
            <span className="text-primary-600 text-sm font-medium">
              {getImpactText(suggestion.savingPotential)}
            </span>
            
            <button className="text-secondary-600 hover:text-secondary-700 flex items-center text-sm font-medium">
              Learn more
              <ArrowRight className="h-4 w-4 ml-1" />
            </button>
          </div>
        </div>
      ))}
      
      <button className="w-full py-3 text-center text-primary-600 font-medium hover:text-primary-700 border border-primary-100 rounded-lg hover:bg-primary-50 transition-colors mt-2">
        View All Suggestions
      </button>
    </div>
  );
};

export default SuggestionsList;