import React from 'react';
import { Leaf, Menu } from 'lucide-react';

interface HeaderProps {
  toggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar }) => {
  return (
    <header className="bg-white shadow-md py-4 px-6 flex justify-between items-center">
      <div className="flex items-center space-x-2">
        <Leaf className="h-8 w-8 text-primary-600" />
        <h1 className="text-2xl font-display font-bold text-gray-800">EcoTrack</h1>
      </div>
      
      <div className="flex items-center space-x-4">
        <button className="md:hidden p-2 rounded-full hover:bg-gray-100" onClick={toggleSidebar}>
          <Menu className="h-6 w-6 text-gray-600" />
        </button>
        
        <div className="hidden md:flex items-center space-x-6">
          <a href="#" className="text-gray-600 hover:text-primary-600 font-medium">Dashboard</a>
          <a href="#" className="text-gray-600 hover:text-primary-600 font-medium">Activities</a>
          <a href="#" className="text-gray-600 hover:text-primary-600 font-medium">Insights</a>
          <a href="#" className="text-gray-600 hover:text-primary-600 font-medium">Tips</a>
        </div>
        
        <button className="bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors">
          Add Activity
        </button>
      </div>
    </header>
  );
};

export default Header;