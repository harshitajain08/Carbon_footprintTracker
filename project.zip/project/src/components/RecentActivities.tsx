import React from 'react';
import { Activity } from '../types';
import { 
  Car, 
  Zap, 
  Utensils, 
  ShoppingBag, 
  Trash2,
  Calendar
} from 'lucide-react';

interface RecentActivitiesProps {
  activities: Activity[];
}

const RecentActivities: React.FC<RecentActivitiesProps> = ({ activities }) => {
  const getCategoryIcon = (activity: Activity) => {
    switch (activity.category) {
      case 'Transportation':
        return <Car className="h-5 w-5 text-secondary-600" />;
      case 'Energy':
        return <Zap className="h-5 w-5 text-warning-500" />;
      case 'Food':
        return <Utensils className="h-5 w-5 text-primary-600" />;
      case 'Shopping':
        return <ShoppingBag className="h-5 w-5 text-secondary-500" />;
      case 'Waste':
        return <Trash2 className="h-5 w-5 text-danger-500" />;
      default:
        return null;
    }
  };
  
  const getImpactColor = (impact: number): string => {
    if (impact < 1) return 'bg-primary-500';
    if (impact < 5) return 'bg-primary-600';
    if (impact < 10) return 'bg-warning-500';
    if (impact < 20) return 'bg-warning-600';
    return 'bg-danger-600';
  };
  
  if (activities.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No activities recorded yet.</p>
        <p className="text-gray-500 mt-2">Add your first activity to start tracking your carbon footprint.</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {activities
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .map((activity) => {
          const carbonImpact = activity.value * activity.carbonPerUnit;
          
          return (
            <div key={activity.id} className="border border-gray-100 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    {getCategoryIcon(activity)}
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-gray-900">{activity.name}</h4>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <Calendar className="h-3.5 w-3.5 mr-1" />
                      {new Date(activity.date).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <span className="font-semibold text-gray-900">{carbonImpact.toFixed(2)} kg CO₂</span>
                  <div className="text-xs text-gray-500 mt-1">
                    {activity.value} {activity.unit}
                  </div>
                </div>
              </div>
              
              <div className="mt-3 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${getImpactColor(carbonImpact)}`}
                  style={{ width: `${Math.min(100, (carbonImpact / 30) * 100)}%` }}
                />
              </div>
            </div>
          );
        })}
    </div>
  );
};

export default RecentActivities;